/* program.c */

#include <stdcc.h>

#pragma region Constructors

/// <remarks />
int main()
{
    print("Hello World!");
    return 0;
}

#pragma endregion

