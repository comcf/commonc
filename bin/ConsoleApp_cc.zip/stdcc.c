// stdcc.c
#include "stdcc.h"

/// <remarks />
int print(const char *format) { return puts(format); }